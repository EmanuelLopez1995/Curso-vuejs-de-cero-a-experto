
export default () => ({
    isLoading: true,
    entries: []
})